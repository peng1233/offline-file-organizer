Offline File Organizer - Marketplace Pack
Generated: 2026-02-09 12:32:20 (GMT+8 local)

Contains:
- marketplace/  (copy/paste-ready text templates + checklists)
- assets/       (demo GIF/PNG and donation QR if present)

Tip: Run repo preflight before publishing: scripts/marketplace-preflight.ps1